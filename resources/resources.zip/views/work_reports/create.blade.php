<!-- resources/views/work_reports/create.blade.php -->

@extends('layout.base')

@section('content')
    <div class="container">
        <h2>Create Work Report</h2>
        <form action="{{ route('work-reports.store') }}" method="post">
            @csrf

            <label for="start_time">Start Time:</label>
            <select name="start_time" id="start_time" required>
                @for ($hour = 8; $hour <= 17; $hour++)
                    @php
                        $time = sprintf('%02d:00', $hour);
                    @endphp
                    <option value="{{ $time }}">{{ $time }}</option>
                @endfor
            </select>

            <label for="end_time">End Time:</label>
            <select name="end_time" id="end_time" required>
                @for ($hour = 8; $hour <= 17; $hour++)
                    @php
                        $time = sprintf('%02d:00', $hour);
                    @endphp
                    <option value="{{ $time }}">{{ $time }}</option>
                @endfor
            </select>

            <label for="work_description">Work Description:</label>
            <textarea name="work_description" id="work_description" rows="4" required></textarea>

            <label for="work_date">Work Date:</label>
            <input type="text" name="work_date" id="work_date" value="{{ now()->toDateString() }}" readonly>

            <button type="submit">Submit</button>
        </form>
    </div>
@endsection

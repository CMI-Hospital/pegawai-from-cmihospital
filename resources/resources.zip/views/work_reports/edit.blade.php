<!-- resources/views/work_reports/edit.blade.php -->

@extends('layout.base')

@section('content')
    <div class="container">
        <h2>Edit Work Report</h2>
        <form action="{{ route('work-reports.update', $workReport->id) }}" method="post">
            @csrf
            @method('PUT')

            <label for="start_time">Start Time:</label>
            <select name="start_time" id="start_time" required>
                @for ($hour = 8; $hour <= 17; $hour++)
                    @php
                        $time = sprintf('%02d:00', $hour);
                    @endphp
                    <option value="{{ $time }}" {{ $workReport->start_time === $time ? 'selected' : '' }}>{{ $time }}</option>
                @endfor
            </select>

            <label for="end_time">End Time:</label>
            <select name="end_time" id="end_time" required>
                @for ($hour = 8; $hour <= 17; $hour++)
                    @php
                        $time = sprintf('%02d:00', $hour);
                    @endphp
                    <option value="{{ $time }}" {{ $workReport->end_time === $time ? 'selected' : '' }}>{{ $time }}</option>
                @endfor
            </select>

            <label for="work_description">Work Description:</label>
            <textarea name="work_description" id="work_description" rows="4" required>{{ $workReport->work_description }}</textarea>

            <label for="work_date">Work Date:</label>
            <input type="text" name="work_date" id="work_date" value="{{ $workReport->work_date }}" readonly>

            <button type="submit">Update</button>
        </form>
    </div>
@endsection

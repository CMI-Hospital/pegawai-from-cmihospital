<!-- resources/views/work_reports/index.blade.php -->

@extends('layout.base')

@section('content')
    <div class="container">
        <h2>Work Reports</h2>

        @if ($role_id == 1 || $role_id == 2)

            <!-- Display form for filtering work reports -->
            <form action="{{ route('work-reports.index') }}" method="get">
                <label for="nama_pegawai">Nama Pegawai:</label>
                <select name="nama_pegawai" id="nama_pegawai">
                    <!-- Populate dropdown with employee names -->
                    @foreach($pegawaiList as $pegawai)
                        <option value="{{ $pegawai->id }}">{{ $pegawai->nama }}</option>
                    @endforeach
                </select>

                <label for="work_date">Work Date:</label>
                <input type="date" name="work_date" id="work_date">

                <button type="submit">Filter</button>
            </form>
        @endif

        <table>
            <thead>
            <tr>
                <th>Start Time</th>
                <th>End Time</th>
                <th>Work Description</th>
                <th>Work Date</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            @foreach ($workReports as $workReport)
                <tr>
                    <td>{{ $workReport->start_time }}</td>
                    <td>{{ $workReport->end_time }}</td>
                    <td>{{ $workReport->work_description }}</td>
                    <td>{{ $workReport->work_date }}</td>
                    <td>
                        @if (auth()->check() && auth()->user()->id == $workReport->user_id)
                            <a href="{{ route('work-reports.edit', $workReport->id) }}">Edit</a>
                            <!-- Add delete button if needed -->
                        @endif
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
@endsection

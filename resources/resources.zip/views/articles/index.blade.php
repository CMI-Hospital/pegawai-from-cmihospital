<!-- resources/views/articles/index.blade.php -->

@extends('layout.base')

@section('content')
    <h1>Article List</h1>

    @foreach ($articles as $article)
        <div>
            <h2>{{ $article->title }}</h2>
            <p>{{ $article->content }}</p>
            <p>Author: {{ $article->pegawai->nama }}</p>
            <a href="{{ route('articles.show', $article->id) }}">View Article</a>
        </div>
    @endforeach
@endsection

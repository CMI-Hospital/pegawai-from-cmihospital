<!-- resources/views/articles/show.blade.php -->

@extends('layout.base')

@section('content')
    <h1>{{ $article->title }}</h1>
    <p>{{ $article->content }}</p>
    <p>Author: {{ $article->pegawai->nama }}</p>

    <!-- Display the "Edit" button if the current user is the author -->
    @can('update', $article)
        <a href="{{ route('articles.edit', $article->id) }}" class="btn btn-primary">Edit</a>
    @endcan

    <!-- Display comments -->
    @foreach ($article->comments as $comment)
        <p>{{ $comment->pegawai->nama }} says: {{ $comment->comment }}</p>
    @endforeach

    <!-- Display comment form if the user is logged in -->
    @auth
    <form action="{{ route('comments.store') }}" method="post">
        @csrf
        <input type="hidden" name="pegawai_id" value="{{ $pegawaiId }}">
        <input type="hidden" name="article_id" value="{{ $article->id }}">
        <textarea name="comment" placeholder="Add a comment"></textarea>
        <button type="submit">Add Comment</button>
    </form>
    @else
        <p>Please log in to leave a comment.</p>
    @endauth

    <!-- Button to go back to articles.index -->
    <a href="{{ route('articles.index') }}" class="btn btn-secondary">Go Back</a>
@endsection

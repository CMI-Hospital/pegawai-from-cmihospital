<!-- resources/views/articles/create.blade.php -->

@extends('layout.base')

@section('content')
    <h1>Create Article</h1>

    <!-- Form to create a new article -->
    <form action="{{ route('articles.store') }}" method="post">
        @csrf

        <input type="hidden" name="pegawai_id" value="{{ $pegawaiId }}">

        <label for="title">Title</label>
        <input type="text" name="title">

        <label for="content">Content</label>
        <textarea name="content"></textarea>

        <!-- Add other necessary fields, such as image upload -->

        <button type="submit">Create Article</button>
    </form>
@endsection

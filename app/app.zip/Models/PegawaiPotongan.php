<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PegawaiPotongan extends Model
{
    use HasFactory;

    protected $table = 'pegawai_potongan';
}
